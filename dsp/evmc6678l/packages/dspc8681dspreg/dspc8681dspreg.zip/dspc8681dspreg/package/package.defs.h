/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-z52
 */

#ifndef dspc8681dspreg__
#define dspc8681dspreg__



#endif /* dspc8681dspreg__ */ 
